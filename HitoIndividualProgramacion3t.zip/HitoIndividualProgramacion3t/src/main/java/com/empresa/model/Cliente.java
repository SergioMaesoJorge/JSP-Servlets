package com.empresa.model;
public class Cliente {
	
		public String nombre;
		public float peso;
		public int eventos;
		public int horas_extra;
		
		public Cliente(String nombre, float peso, int eventos, int horas_extra) {
			super();
			this.nombre = nombre;
			this.peso = peso;
			this.eventos = eventos;
			this.horas_extra = horas_extra;
		}

		public String getNombre() {
			return nombre;
		}

		public void setNombre(String nombre) {
			this.nombre = nombre;
		}

		public float getPeso() {
			return peso;
		}

		public void setPeso(float peso) {
			this.peso = peso;
		}

		public int getEventos() {
			return eventos;
		}

		public void setEventos(int eventos) {
			this.eventos = eventos;
		}

		public int getHoras_extra() {
			return horas_extra;
		}

		public void setHoras_extra(int horas_extra) {
			this.horas_extra = horas_extra;
		}
}
