package com.practica.collectionsweb;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Menu extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private String[] menus = {
        "Lunes: Comida - Pasta, Bebida - Agua, Postre - Fruta",
        "Martes: Comida - Ensalada, Bebida - Refresco, Postre - Helado",
        "Miércoles: Comida - Pollo asado, Bebida - Jugo, Postre - Pastel",
        "Jueves: Comida - Sopa, Bebida - Té, Postre - Galletas",
        "Viernes: Comida - Pizza, Bebida - Cerveza, Postre - Flan",
        "Sábado: Comida - Parrillada, Bebida - Vino, Postre - Natillas",
        "Domingo: Comida - Pescado, Bebida - Limonada, Postre - Mousse"
    };

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        int dayOfWeek = 3; // Miércoles

        out.println("<html><body>");
        out.println("<h2>Menú del día</h2>");
        out.println("<p>" + menus[dayOfWeek] + "</p>");
        out.println("</body></html>");
    }
}