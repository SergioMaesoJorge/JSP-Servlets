package com.teoria;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Calcular
 */
@WebServlet("/Calcular")
public class Calcular extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Calcular() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtener el parámetro "importe" del formulario
        String importeStr = request.getParameter("importe");

        // Verificar si el parámetro está presente y no es vacío
        if (importeStr != null && !importeStr.isEmpty()) {
            try {
                // Convertir el valor del parámetro a un número decimal
                double importe = Double.parseDouble(importeStr);

                // Realizar el cálculo multiplicando el importe por 1.17
                double resultado = importe * 1.17;

                // Configurar la respuesta con el resultado
                response.setContentType("text/html");
                PrintWriter out = response.getWriter();
                out.println("<html>");
                out.println("<head><title>Resultado</title></head>");
                out.println("<body>");
                out.println("<h1>Resultado de la multiplicación:</h1>");
                out.println("<p>Importe: " + importe + "</p>");
                out.println("<p>Resultado: " + resultado + "</p>");
                out.println("</body>");
                out.println("</html>");
            } catch (NumberFormatException e) {
                // Manejar el caso en el que el valor del parámetro no sea un número válido
                response.setContentType("text/html");
                PrintWriter out = response.getWriter();
                out.println("<html>");
                out.println("<head><title>Error</title></head>");
                out.println("<body>");
                out.println("<h1>Error: El valor ingresado no es válido.</h1>");
                out.println("</body>");
                out.println("</html>");
            }
        } else {
            // Manejar el caso en el que no se haya proporcionado un valor para el parámetro
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<html>");
            out.println("<head><title>Error</title></head>");
            out.println("<body>");
            out.println("<h1>Error: No se ha proporcionado un valor para el importe.</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		int numero1=Integer.parseInt(request.getParameter("numero1"));
		int numero2=Integer.parseInt(request.getParameter("numero2"));
		int solucion = 0;
		try {
			solucion=numero1/numero2;
		} catch (ArithmeticException e){
			
			response.getWriter().append("No es posible dividir por 0 ");
		}catch (Exception e) {
			response.getWriter().append("No funciona "+e.getMessage());
		}
		response.getWriter().append("La solución es "+ solucion);
	}

}
