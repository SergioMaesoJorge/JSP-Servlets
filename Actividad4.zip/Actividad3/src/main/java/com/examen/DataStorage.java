package com.examen;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DataStorage {
    private List<String> data;

    public DataStorage() {
        data = new ArrayList<>();
    }

    public void addData(String item) {
        data.add(item);
    }

    public List<String> getData() {
        return data;
    }

    public void sortData() {
        Collections.sort(data);
    }
}
