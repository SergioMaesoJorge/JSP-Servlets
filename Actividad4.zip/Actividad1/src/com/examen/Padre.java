package com.examen;

import java.util.Date;

public class Padre {
	protected int unidadesEnStock;
    protected int unidadesEnPedido;
    protected Date fechaCaducidad;

	public int getUnidadesEnStock() {
		return unidadesEnStock;
	}

	public void setUnidadesEnStock(int unidadesEnStock) {
		this.unidadesEnStock = unidadesEnStock;
	}

	public int getUnidadesEnPedido() {
		return unidadesEnPedido;
	}

	public void setUnidadesEnPedido(int unidadesEnPedido) {
		this.unidadesEnPedido = unidadesEnPedido;
	}

	public Date getFechaCaducidad() {
		return fechaCaducidad;
	}

	public void setFechaCaducidad(Date fechaCaducidad) {
		this.fechaCaducidad = fechaCaducidad;
	}
	public Padre() {
		// TODO Auto-generated constructor stub
		
	}
	public Padre(int unidadesEnStock, int unidadesEnPedido, Date fechaCaducidad) {
		super();
		this.unidadesEnStock = unidadesEnStock;
		this.unidadesEnPedido = unidadesEnPedido;
		this.fechaCaducidad = fechaCaducidad;
	}


	
	 // Método para obtener la cantidad total de unidades
    public int obtenerCantidadTotal() {
        return unidadesEnStock + unidadesEnPedido;
    }

    // Método para comprobar si el producto ha caducado
    public boolean haCaducado() {
        Date fechaActual = new Date();
        return fechaCaducidad.before(fechaActual);
    }

}
