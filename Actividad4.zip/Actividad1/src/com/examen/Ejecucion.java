package com.examen;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Ejecucion {
    public static void main(String[] args) {
        List<Frutas> productos = new ArrayList<>();

        // Crear formato de fecha
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

        try {
            // Crear los productos
            Date fechaManzana = dateFormat.parse("15/03/2021");
            Frutas manzana = new Frutas(100, 80, fechaManzana, "Manzana", 9.95);
            productos.add(manzana);

            Date fechaPeras = dateFormat.parse("21/03/2021");
            Frutas peras = new Frutas(150, 95, fechaPeras, "Peras", 15.95);
            productos.add(peras);

            Date fechaNaranjas = dateFormat.parse("20/03/2021");
            Frutas naranjas = new Frutas(100, 75, fechaNaranjas, "Naranjas", 7.95);
            productos.add(naranjas);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        // Mostrar la tabla de productos
        System.out.println("Nombre\t\tStock\tPedido\tCaducidad\tPrecio\tValor Inventario");
        for (Frutas producto : productos) {
            System.out.println(producto.getNombreProducto() + "\t\t" +
                    producto.getUnidadesEnStock() + "\t" +
                    producto.getUnidadesEnPedido() + "\t" +
                    dateFormat.format(producto.getFechaCaducidad()) + "\t" +
                    producto.getPrecioUnitario() + "\t" +
                    producto.calcularValorInventario2());
        }
    }
}