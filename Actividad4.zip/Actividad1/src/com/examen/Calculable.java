package com.examen;

public interface Calculable {
    double calcularValorInventario2();
}