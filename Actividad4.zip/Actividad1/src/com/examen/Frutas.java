package com.examen;

import java.util.Date;

public class Frutas extends Padre implements Calculable {
    private String nombreProducto;
    private double precioUnitario;

    // Constructor sin parámetros
    public Frutas() {
    	super();
    }

    // Constructor con parámetros
    public Frutas(int unidadesEnStock, int unidadesEnPedido, Date fechaCaducidad, String nombreProducto, double precioUnitario) {
        super(unidadesEnStock, unidadesEnPedido, fechaCaducidad);
        this.nombreProducto = nombreProducto;
        this.precioUnitario = precioUnitario;
    }

    // Getter y Setter para nombreProducto
    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    // Getter y Setter para precioUnitario
    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(double precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    // Otros métodos adicionales de la clase Frutas

    // Método para calcular el valor total del inventario de frutas
    public double calcularValorInventario() {
        return unidadesEnStock * precioUnitario;
    }

    // Método para obtener la información completa de la fruta
    public String obtenerInformacionCompleta() {
        return "Nombre: " + nombreProducto + "\n" +
               "Unidades en stock: " + unidadesEnStock + "\n" +
               "Unidades en pedido: " + unidadesEnPedido + "\n" +
               "Fecha de caducidad: " + fechaCaducidad + "\n" +
               "Precio unitario: " + precioUnitario + "\n" +
               "Valor total del inventario: " + calcularValorInventario();
    }
    
    @Override
    public double calcularValorInventario2() {
        int stockDisponible = unidadesEnStock - unidadesEnPedido;
        return stockDisponible * precioUnitario;
    }
}