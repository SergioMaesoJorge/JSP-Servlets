package com.examen;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AsignaturasServlet
 */
@WebServlet("/AsignaturasServlet")
public class AsignaturasServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	 private static final String JDBC_URL = "jdbc:mysql://localhost:3306/examen3t";
	    private static final String JDBC_USERNAME = "root";
	    private static final String JDBC_PASSWORD = "";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AsignaturasServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	 protected void doPost(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	        // Obtener los valores de las asignaturas
	        String asignatura1 = request.getParameter("asignatura1");
	        String asignatura2 = request.getParameter("asignatura2");
	        String asignatura3 = request.getParameter("asignatura3");
	        String asignatura4 = request.getParameter("asignatura4");
	        String asignatura5 = request.getParameter("asignatura5");

	        // Guardar los valores en la base de datos
	        guardarAsignaturas(asignatura1, asignatura2, asignatura3, asignatura4, asignatura5);

	        // Construir el mensaje de finalización y las asignaturas introducidas
	        String mensaje = "Has finalizado. Las asignaturas introducidas son:<br>"
	                + "Asignatura 1: " + asignatura1 + "<br>"
	                + "Asignatura 2: " + asignatura2 + "<br>"
	                + "Asignatura 3: " + asignatura3 + "<br>"
	                + "Asignatura 4: " + asignatura4 + "<br>"
	                + "Asignatura 5: " + asignatura5;

	        // Configurar el tipo de contenido de la respuesta como HTML
	        response.setContentType("text/html");

	        // Escribir el mensaje en la respuesta
	        PrintWriter out = response.getWriter();
	        out.println("<html><body>");
	        out.println("<h1>¡Finalizado!</h1>");
	        out.println("<p>" + mensaje + "</p>");
	        out.println("</body></html>");
	    }
	    
	 private void guardarAsignaturas(String asignatura1, String asignatura2, String asignatura3, String asignatura4, String asignatura5) {
		    try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD);
		         PreparedStatement stmt = conn.prepareStatement("INSERT INTO asignaturas2 (asignatura1, asignatura2, asignatura3, asignatura4, asignatura5) VALUES (?, ?, ?, ?, ?)")) {
		        stmt.setString(1, asignatura1);
		        stmt.setString(2, asignatura2);
		        stmt.setString(3, asignatura3);
		        stmt.setString(4, asignatura4);
		        stmt.setString(5, asignatura5);
		        int rowsAffected = stmt.executeUpdate();

		        if (rowsAffected > 0) {
		            System.out.println("Las asignaturas se han guardado correctamente en la base de datos.");
		        } else {
		            System.out.println("No se han guardado las asignaturas en la base de datos.");
		        }
		    } catch (SQLException e) {
		        e.printStackTrace();
		        // Manejar el error de conexión o inserción en la base de datos según sea necesario
		    }
		}


}
